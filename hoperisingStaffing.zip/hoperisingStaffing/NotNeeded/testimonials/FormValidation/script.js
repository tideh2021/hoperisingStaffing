// script.js validates the form, trim() the inputed values; adds success and error classes to the form

const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');
const password2 = document.getElementById('password2');

form.addEventListener('submit', (e) => {
  e.preventDefault();

  checkInputs();
});

function checkInputs() {
  /* get the value for the inputs and use trim() to remove the white spaces in the input */
  const usernameValue = username.value.trim();
  const emailValue = email.value.trim();
  const passwordValue = password.value.trim();
  const password2Value = password2.value.trim();

  if (usernameValue === '') {
    setErrorFor(username, 'Name cannot be blank');
  } else {
    setSuccessFor(username);
  }
  if (emailValue === '') {
    setErrorFor(email, 'Email cannot be blank');
  } else if (!isEmail(emailValue)) {
    setErrorFor(email, 'Email is not valid');
  } else {
    setSuccessFor(email);
  }

  if (passwordValue === '') {
    setErrorFor(password, 'Password cannot be blank');
  } else {
    setSuccessFor(password);
  }

  if (password2Value === '') {
    setErrorFor(password2, 'Password2 cannot be blank');
  } else if (passwordValue !== password2Value) {
    preventDefault();
    setErrorFor(password2, 'Password does not match');
  } else {
    setSuccessFor(password2);
  }
  // show success message alert message if you want
}

// function to add error class to html
function setErrorFor(input, message) {
  const formControl = input.parentElement; /* for .form-control */
  const small = formControl.querySelector('small');
  /*add error message inside small */
  small.innerText = message;
  // Take away the success and error class from html
  //add error class to html using Js
  formControl.className = 'form-control error';
}
// function to add success class to html
function setSuccessFor(input) {
  const formControl = input.parentElement;
  // add success class to html form
  formControl.className = 'form-control success';

}
// check email validation
function isEmail(email) {
  return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}


