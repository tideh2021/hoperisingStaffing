<?php
include_once '../include/header.php';
?>

<!-- <!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="styles1.css">
</head>

<body> -->
  <h1>Send Email Using smtp server in phpEmailer</h1>
  <section class="employer-sect">
    <div class="container">
      <div class="header">
        <h2>Your Contact Details</h2>
      </div>

      <?php
      include_once './attachApp.php';
      ?>

      <form class="form" id="form" method="POST" enctype="multipart/form-data">
        <div class="form-control1">
          <label>Name:</label>
          <input type="text" placeholder="Enter your name" id="personName" name="personName"></input>
          <i class="fas fa-check-circle"></i>
          <i class="fas fa-exclamation-circle"></i>
          <small>Error message</small>
        </div>
        <div class="form-control1">
          <label>Phone Number:</label>
          <input type="phone" placeholder="Enter contact phone number" id="phone" name="phone"></input>
          <i class="fas fa-check-circle"></i>
          <i class="fas fa-exclamation-circle"></i>
          <small>Error message</small>
        </div>

        <div class="form-control1">
          <label>Email:</label>
          <input type="email" placeholder="Enter your email here" id="email" name="email"></input>
          <i class="fas fa-check-circle"></i>
          <i class="fas fa-exclamation-circle"></i>
          <small>Error message</small>
        </div>

        <div class="form-control1">
          <label>Subject:</label>
          <input type="text" placeholder="Enter Subject...." id="subject" name="subject"></input>
          <i class="fas fa-check-circle"></i>
          <i class="fas fa-exclamation-circle"></i>
          <small>Error message</small>
        </div>
        <div class="text-area">
          <label for="message">Message</label>
          <textarea name="message" id="message" cols="30" rows="6" placeholder="Enter your message" name="text-area"></textarea>
        </div>
        <!-- File upload php-->
        <div class="file-div">
          <?php if (empty($msg)) { ?>
            <input type="hidden" name="MAX_FILE_SIZE" value="900000">
            Add attachment:
            <input name="userfile[]" type="file" multiple>
          <?php } else {
            echo htmlspecialchars($msg);
          } ?>
        </div>
        <!-- Button  -->
        <button type="submit" name="send" value="send">Send</button>
      </form>
    </div>
  </section>
  <!-- <script src="" async defer></script>
</body>

</html> -->
<?php
include_once '../include/header.php';
?>