<footer>
  <div id="footer-div">
    <div id="coy-name">
      <h1 class="logo">Hoperising Staffing Links Inc.</h1>
    </div>
    <ul id="footer-nav">
      <li>
        <a href="https://www.youtube.com" target="_blank">
          <img src="https://img.icons8.com/external-justicon-flat-justicon/64/000000/external-youtube-social-media-justicon-flat-justicon.png" alt="Youtube icon" />
          Youtube</a>
      </li>
      <li>
        <a href="https://www.spotify.com" target="_blank">
          <img src="https://img.icons8.com/fluency/48/000000/spotify.png" alt="Spotify Icon" />
          Spotify</a>
      </li>
      <li>
        <a href="https://www.facebook.com" target="_blank">
          <img src="https://img.icons8.com/fluency/48/000000/facebook-new.png" alt="facebook icon" />
          Facebook</a>
      </li>
    </ul>
  </div>
  <div id="footer-p">
    <a href="https://icons8.com/icon/uLWV5A9vXIPu/facebook">Footer icon by Icons8</a>
    <a href="https://www.flaticon.com/free-icons/home-button" title="home button icons">Home button icons created by
      Freepik - Flaticon</a>
    <a href="https://www.freepik.com/photos/home-care">Home care photo created by freepik - www.freepik.com</a>
  </div>
</footer>
<?php
include 'C:\xampp\htdocs\hoperisingStaffing\formwithAttachment\hamburgerApp.php';
?>

<!-- C:\xampp\htdocs\hoperisingStaffing\formwithAttachment\include\footer.php -->
<!-- <script type="text/javascript" src="./hamburgerApp.js"></script> -->
</body>

</html>